import { Link } from 'react-router-dom';

function Head() {
  return (
    <header className="head">
      <Link to="/news">Новости</Link>
      <Link to="/about">О проекте</Link>
      <Link to="/contacts">Контакты</Link>
    </header>
  );
}

export default Head;
