function Footer() {
  return (
    <footer className="footer">
      <p>Дата создания сайта: 15 апреля 2024 г.</p>
      <p>Автор: Воронцов Андрей</p>
    </footer>
  );
}

export default Footer;
