function Section() {
  return (
    <section className="section">
      <img src="https://placehold.co/200x100" alt="" />
    </section>
  );
}

export default Section;
