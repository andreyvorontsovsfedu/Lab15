import { Route, Routes } from 'react-router-dom';

function Article() {
  return (
    <article className="article">
      <Routes>
        <Route index element={<p>Это главная страница</p>} />
        <Route
          path="news"
          element={
            <>
              <h1>Привет мир!</h1>
              <p>Страница новости</p>
            </>
          }
        />
        <Route path="about" element={<h1>Южный федеральный университет</h1>} />
        <Route
          path="contacts"
          element={<p>Воронцов Андрей - 8 928 199-46-86</p>}
        />
        <Route path="*" element={<h1>404 страница не найдена</h1>} />
      </Routes>
    </article>
  );
}

export default Article;
