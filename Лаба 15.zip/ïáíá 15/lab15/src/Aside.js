function Aside() {
  return (
    <aside className="aside">
      <p>Воронцов</p>
      <p>Андрей</p>
      <p>Александрович</p>
    </aside>
  );
}

export default Aside;
